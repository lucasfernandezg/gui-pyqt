El archivo "main" que hay que ejecutar es TestGUIApp.py .
El resto de los archivos son funciones u objetos que se importan en el "main".

mplwiget.py: Crea el objeto de Matplotlib para los graficos.
mystylesheet.py: es solo para el estilo (colores etc).
TestGUI.py: Se crean todos los objetos (botones, barras, cuadros de texto...), su posicion y tamaño.
TestGUIApp.py: Se importa todo lo demas y se le da la funcionalidad y la logica.
